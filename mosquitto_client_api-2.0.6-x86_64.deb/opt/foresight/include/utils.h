/**
* @file   utils.h
* @brief  Function of stract of _ONFIGINFO_API 
* @date   24/03/2021
* @author Eldad Gostynski
* @issue
*
* Insert detailed description here
*/
#ifndef UTILS_H_
#define UTILS_H_

#include <fcntl.h>
#include <stdint.h>
#include <string>

#include "foresight/common/mqtt_file_struct_def.h"
#include "mqtt_callback.h"

#ifdef __cplusplus
extern "C" {
#endif

constexpr std::int32_t MAX_RX_MQTT_FILES_API = 12;
constexpr std::int32_t MAX_TX_MQTT_FILES_API = 12;

constexpr std::int32_t MAX_MQTT_FILE_SIZE = (1024*1024);
constexpr std::int32_t MAX_LINE_SIZE_API  = 256;

constexpr std::int32_t MAX_DAY_NIGHT_DIRS_NAMES = 4;
constexpr std::int32_t API_QOS                  = 2; // Quality of service

constexpr std::int32_t FTYPE_NONE    = 0;
constexpr std::int32_t FTYPE_PS_CONF = 1;
constexpr std::int32_t FTYPE_VS_CONF = 2;

typedef struct _CONFIGINFO_API
{
    char path[MAX_LINE_SIZE_API];
    char pb_out_path[MAX_LINE_SIZE_API];
    char cam_out_path[MAX_LINE_SIZE_API];


    char g_topic_file_rx[MAX_LINE_SIZE_API];
    char g_topic_file_tx[MAX_LINE_SIZE_API];
 
    //---------- Files playback
    // File, transfer by MQTT

    char g_mqtt_file_rx_paths[MAX_RX_MQTT_FILES_API][MAX_LINE_SIZE_API];
    char g_mqtt_file_tx_paths[MAX_TX_MQTT_FILES_API][MAX_LINE_SIZE_API];

    MQTTFILE   rmf;
    char mqtt_sbuf[MAX_MQTT_FILE_SIZE + 128];
    char * mqtt_file_rd_buf;

    char g_mqtt_id[40];
    char g_mqtt_topic_shell_rx[MAX_LINE_SIZE_API];
    char g_mqtt_topic_shell_tx[MAX_LINE_SIZE_API];
    char g_mqtt_topic_data_tx[MAX_LINE_SIZE_API];
    char g_mqtt_topic_hb[MAX_LINE_SIZE_API];
    char g_mqtt_topic_hb_vs[MAX_LINE_SIZE_API];
    char g_mqtt_topic_cam_rx[MAX_LINE_SIZE_API];

    char g_mqtt_topic_shell_vs_rx[MAX_LINE_SIZE_API];
    char g_mqtt_topic_log_ps_tx[MAX_LINE_SIZE_API];
    char g_mqtt_topic_log_vs_tx[MAX_LINE_SIZE_API];
    char g_mqtt_topic_data_vs_tx[MAX_LINE_SIZE_API];
    char g_mqtt_host[64]; // = //"127.0.0.1";
    int g_mqtt_port; // = 1883;
    int g_mqtt_data_request;

    int UseMQTTToken;
    char OwnMQTTToken[MAX_LINE_SIZE_API];
    char PeerMQTTToken[MAX_LINE_SIZE_API];
    int PeerMQTTTokenLen;

    char child_argv_vs[1024];
    char child_exe_full_path_vs[2048];
    char child_argv_calib[1024];
    char child_exe_full_path_calib[2048];
    MqttCallback *callback_class =nullptr;
}CONFIGINFO_API;

/**
 * @brief Get Global Ps Config Api
 * @return pointer to g_pssysconfig
 */
CONFIGINFO_API * getGlobalPsConfigApi(void);




/**
 * @brief Set Init Mosquitto Client Api
 * @param pi - pointer to CONFIGINFO_API
 * @return 
  *	MOSQ_ERR_SUCCESS - on success.
 * 	ERROR_MQTT_FAIL_TO_INIT 
 * 	ERROR_MQTT_FAIL_TO_SUBSCRIBE 
 */
int setInitMosquittoClientApi(CONFIGINFO_API * pi);

/**
 * @brief Open Mqtt Client Init
 * @param id - mqtt_id - String to use as the client id. If NULL, a random client id
 * 	                will be generated. If id is NULL, clean_session must be true.
 * @param clean_session -  true to instruct the broker to clean all messages
 *                  and subscriptions on disconnect, 
 *                         false to instruct it to keep them. 
 * @param user_data -pointer that will be passed as an argument to any
 *                  callbacks that are specified.
 * @return (void)
 */
void openMqttClientInit(const char * id, int clean_session, void * user_data);


/**
 * @brief Mqtt Send File Api
 * @param si - pointer to CONFIGINFO_API
 * @param mqtt_topic - mqtt topic string
 * @param full_file_name -full file name 
 * @param num_file - for receiver side
 * @return 
 * 	NO_ERROR             -      on success.
 * 	ERROR_MQTT_SEND_FILE -      on fail 
 */
int mqttSendFileApi(CONFIGINFO_API * si,
                   char * mqtt_topic,
                   char * full_file_name,
                   int num_file); 

#ifdef __cplusplus
}
#endif


#endif /* UTILS_H_ */

