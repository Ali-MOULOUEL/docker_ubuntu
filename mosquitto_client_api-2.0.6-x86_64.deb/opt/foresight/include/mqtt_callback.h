/**
* @file   mqtt_callback.h
* @brief  All function of Callback for GUI
* @date   06/04/2022
* @author Gabi Gvili
* @issue
*
* Insert detailed description here
*/

#ifndef QUADSIGHTGUI_MQTT_CALLBACK_H
#define QUADSIGHTGUI_MQTT_CALLBACK_H


class MqttCallback 
{
public:
    virtual void callBackCameraInfo()=0;
    virtual void callBackCfgInfo()=0;
    virtual void callBackDirList(char *data, int length)=0;
    virtual void callBackBrwInfo(char *data, int length)=0;
    virtual void callBackCfgInfoSaved()=0;
    virtual void callBackGotCfgCamera()=0;
    virtual void callBackVisionServiceDown()=0;
    virtual void callBackGotBuildVersion(char *buildVersion)=0;
    virtual void callBackGotPsVersion(char *psVersion)=0;
    virtual void callBackGotVsVersion(char *vsVersion)=0;
    virtual void callBackGotLibDspVersion(char *libDspVersion)=0;
    virtual void callBackGotFrameNumber(int frameNum)=0;
    virtual void callBackLoadMovieSucceed(int frameCount)=0;
    virtual void callBackGotPause()=0;
    virtual void callBackGotGtf()=0;
    virtual void callBackVsChangeMode(bool isVsOn)=0;
    virtual void callBackGotVsData(char *data)=0;

    virtual void callBackGotLogFromVs(char *data)=0;
    virtual void callBackGotLogFromPs(char *data)=0;
    virtual void callBackGotFileFromPs(char *data)=0;
    virtual void callBackGotPsHeartbeat(char *data)=0;
    virtual void callBackGotVsHeartbeat(char *data)=0;
};
#endif //QUADSIGHTGUI_MQTT_CALLBACK_H
