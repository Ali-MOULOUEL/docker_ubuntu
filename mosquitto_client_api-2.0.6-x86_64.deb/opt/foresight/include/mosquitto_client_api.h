/**
* @file   mosquitto_client_api.h
* @brief  All function of Client API Lib
* @date   24/03/2021
* @author Eldad Gostynski
* @issue
*
* Insert detailed description here
*/

#ifndef MOSQUITTO_CLIENT_API_MOSQUITTO_CLIENT_API_H
#define MOSQUITTO_CLIENT_API_MOSQUITTO_CLIENT_API_H

#include "utils.h"

#define API_VERSION_MAJOR   2
#define API_VERSION_MINOR   0
#define API_VERSION_PATCH   6

constexpr char FILE_CAMERA_CONFIG_IN[] = "/dev/shm/cam_rx_api_data";
constexpr char FILE_CAMERA_CONFIG_OUT[] = "/dev/shm/cam_tx_api_data.txt";
constexpr char FILE_CONFIG_IN[] = "/dev/shm/cfg_rx_api_data";
constexpr char FILE_CONFIG_OUT[] = "/dev/shm/cfg_rx_api_data.txt";

constexpr std::uint32_t SLEEP_TIME =20000;

constexpr std::uint32_t N_TIME_OUT      =  100;
constexpr std::uint32_t N_TIME_OUT_MID  =  200;
constexpr std::uint32_t N_TIME_OUT_LONG = 2000;

constexpr std::int32_t NO_SET_STATUS = -1;

enum ErrorCode
{
    NO_ERROR                     = 0,
    ERROR_FAIL_TO_OPEN_FILE      = -1,
    ERROR_FAIL_TO_INIT_MOSQUITTO = -100,
    ERROR_TIME_OUT               = -101,
    ERROR_FAIL_LOAD_DIR          = -102,
    ERROR_CAN_NOT_START_VS_TWICE = -103,
    ERROR_INPUT_PARAMS           = -104,
    ERROR_NO_VAL                 = -105,
    ERROR_CAN_NOT_OPEN_FILE      = -106,
    ERROR_FAIL_CALIBRATION_GYRO  = -107

};

enum VideoType
{
    e_AVI    = 0,
    e_8_BIT  = 1,
    e_16_BIT = 2
};

enum RigType
{
    e_RIG_32     = 0,
    e_RIG_90     = 1,
    e_MODULAR_32 = 2,
    e_MODULAR_90 = 3
};

enum PlaybackStatus
{
    INIT_PLAYBACK       = 0,
    VS_ON               = 1,
    SUCCESS_LOAD_DIR    = 2,
    FAIL_LOAD_DIR       = 3,
    READY_FOR_RUN_PLAYBACK_ACK_FROM_AUTO_CALIB        = 4,
    RUN_PLAYBACK        = 5,
    FINISH_PLAYBACK     = 6,
    VISION_SERVICE_IS_KILLED  = 7
};

enum IpStatus
{
    INIT_IP       = 0,
    SET_IP        = 1
};

enum SetAlgoStatus
{
    INIT_SET_ALGO       = 0,
    ACK_SET_ALGO        = 1
};

enum SetDisparityType
{
    INIT_SET_DISPARITY       = 0,
    ACK_SET_DISPARITY        = 1
};
enum SetSendCmdStatus
{
    INIT_SEND_CMD       = 0,
    ACK_SEND_CMD        = 1
};

enum SetSendSensorCmdStatus
{
    INIT_SET_SENSOR_CMD       = 0,
    ACK_SET_SENSOR_CMD        = 1
};

enum CheckDirConfigCameraExistStatus
{
    INIT_CHECK_DIR_CONFIG_CMD          = 0,
    ACK_CHECK_DIR_CONFIG_EXIST_CMD     = 1,
    ACK_CHECK_DIR_CONFIG_NOT_EXIST_CMD = 2
};

enum SetAutoCalibStatus
{
    INIT_AUTO_CALIB_CMD       = 0,
    ACK_AUTO_CALIB_CMD        = 1
};

enum SetGyroCalibStatus
{
    INIT_SET_GYRO_CALIB   = 0,
    ACK_SET_GYRO_CALIB    = 1
};

enum SetLiveCamerasStatus
{
    INIT_LIVE_CAMERAS       = 0,
    ACK_GET_CAMERAS_PRAM    = 1,
    ACK_SAVE_CAMERAS_PARM   = 2,
    ACK_READY_CAMERAS       = 3,
    ACK_CAMERAS_DSP_OPEN    = 4,
    ACK_CAMERAS_LIVE        = 5,
    ACK_CAMERAS_KILL_VISION_SERVICE =6
};

enum SetRecordLiveCamerasStatus
{
    INIT_RECORD_LIVE_CAMERAS       = 0,
    ACK_GET_RECORD_PRAM            = 1,
    ACK_SAVE_RECORD_PARM           = 2,
    ACK_READY_RECORD               = 3,
    ACK_START_RECORD               = 4,
	ACK_KILL_VISION_SERVICE  	   = 5
};

enum RequestData
{
    LEFT_OT             = (1<<1),   // send sensor left camera video
    RIGHT_OT            = (1<<2),   // send sensor right camera video
    SEND_EPOC_TIME_OT   = (1<<3),   // send sensor send epoc time
    OBSTACLES_OT        = (1<<5),   // send sensor objects detection data information
    VIRTUAL_PATH_OT     = (1<<7),   // send sensor virtual path
    EGO_OT              = (1<<8),   // send sensor ego car data information
    MAP_DELTA_XY_OT     = (1<<9),   // send sensor map delta xy
    GROUND_OT           = (1<<10),  // send sensor ground mask
    STATUS_OT           = (1<<12),  // send sensor system status information
    DEPTH_PCL_OT        = (1<<13),  // send sensor depth map overlay information
    QMAT_OT             = (1<<14),  // send sensor reproduction Q matrix
    PCL_XYZ_OT          = (1<<15),  // send sensor point cloud image
    RECTIFIED_OT        = (1<<16),  //send sensor left rectified image
    BIRD_EYE_OT         = (1<<17),  // send sensor bird eye view image
    LANES_OT            = (1<<18),  // send sensor lanes mask image
    RS_OT               = (1<<19),  // send sensor road surface mask image
    FPS_OT              = (1<<20),  // send sensor average fps
    BIG_PIC_OT          = (1<<27),  // send sensor big video
    DISP_OT             = (1<<28)   // send sensor disparity map image
};

enum ShowVideoData {
    VIDEO_LEFT_RIGHT_OT    = LEFT_OT | RIGHT_OT,
    VIDEO_OBSTACLES_OT     = LEFT_OT | RIGHT_OT | OBSTACLES_OT,
    VIDEO_OBSTACLES_RS_OT  = LEFT_OT | RIGHT_OT | OBSTACLES_OT | RS_OT | LANES_OT,
    VIDEO_DISPARITY_OT     = LEFT_OT | DISP_OT  | OBSTACLES_OT,
    VIDEO_LEFT_AND_POINT_CLOUD_OT    = LEFT_OT |DEPTH_PCL_OT |QMAT_OT |RECTIFIED_OT,
    VIDEO_LEFT_RECTIFIED_AND_POINT_CLOUD_OT   = DEPTH_PCL_OT |QMAT_OT |RECTIFIED_OT,
    VIDEO_LEFT_AND_POINT_CLOUD_XYZ_OT         = LEFT_OT | PCL_XYZ_OT,
    VIDEO_LEFT_RECTIFIED_AND_POINT_CLOUD_XYZ_OT = RECTIFIED_OT | PCL_XYZ_OT,
    VIDEO_BRID_EYE_OT      = BIRD_EYE_OT
};

enum ShowVideoshowVideo
{
    SHOW_VIDEO_NONE_OT          = 0,
    SHOW_VIDEO_LEFT_RIGHT_OT    = 1,
    SHOW_VIDEO_OBSTACLES_OT     = 2,
    SHOW_VIDEO_OBSTACLES_RS_OT  = 3,
    SHOW_VIDEO_DISPARITY_OT     = 4,
    SHOW_VIDEO_LEFT_AND_POINT_CLOUD_OT   = 5,
    SHOW_VIDEO_LEFT_RECTIFIED_AND_POINT_CLOUD_OT     = 6,
    SHOW_VIDEO_LEFT_AND_POINT_CLOUD_XYZ_OT           = 7,
    SHOW_VIDEO_LEFT_RECTIFIED_AND_POINT_CLOUD_XYZ_OT = 8,
    SHOW_VIDEO_BRID_EYE_OT      = 9
};

enum MetadataRequest
{
    NO_METADATA            = 0,
    JSON_FILE_OT           = 1U,       // Request create json file
    DISPARITY_16BIT_OT     = (1<<1),   // Request create metadata of Disparity16
    RANGER_OT              = (1<<2),   // Request create metadata of Ranger
    RANGER_UN_REC_OT       = (1<<3),   // Request create metadata of RangerUnRect
    TRACKER_IMAGE_OT       = (1<<4),   // Request create metadata of TrackerImage
    RECTIFIED_LEFT_RGB_OT  = (1<<5),   // Request create metadata of RectifiedLeftRGB
    GROUND_MASK_OT         = (1<<6),   // Request create metadata of GroundMask
    BIRD_EYE_VIEW_OT       = (1<<7),   // Request create metadata of BirdsEyeView
    GYRO_MASK_OT           = (1<<8),   // Request create metadata of GyroMask
    PATH_MASK_OT           = (1<<9),   // Request create metadata of PathMask
    DISPARITY_SG_OT        = (1<<10),   // Request create metadata of DisparitySG
    PCL_OT                 = (1<<11),   // Request create metadata of Pcl
    SEGMENTATION_OT        = (1<<12),   // Request create metadata of Segmentation
    ROAD_MASK_OT           = (1<<13),   // Request create metadata of RoadMask
    LANE_DETECTION_MASK_OT = (1<<14),   // Request create metadata of LaneDetectionMask
    CONFIDENCE_MAP_OT      = (1<<15),   // Request create metadata of ConfidenceMap
    RAFT_DX_OT             = (1<<16),   // Request create metadata of Raft_Dx
    RAFT_DY_OT             = (1<<17),   // Request create metadata of Raft_Dy

    VALIDATION_MASK_OT     = (1<<31),   // Request create metadata of Validation Mode
    ALL_METADATA_OT        = (0xFFFFFFFF & (~VALIDATION_MASK_OT)) // Request create All metadata
};

enum RangerSourceDisplayData
{
    LEFT_VIS        = 0,
    LEFT_IR         = 2,
    DISPARITY_VIS   = 6,
    DISPARITY_IR    = 7
};

enum DirFilesType
{
    INPUT_DIR_RECORD      = 0,
    INPUT_DIR_PLAYBACK    = 1,
    INPUT_DISPARITY_VIS   = 2,
    INPUT_DISPARITY_IR    = 3,
    INPUT_SEND_MQTT_OBST  = 4,
    CREATE_AUTO_CLIB_FILE = 5
};



/* Disparity type*/
enum enum_DisparityType
{
    BLOCK_MATCHING  = 0,
    ANY_NET         = 1,
    RAFT            = 2,
    RAFT_NP         = 3
};

/**
 * @brief Set Callback function for gui
 * @param _callback
 * @return (void)
 */
void setCallback(MqttCallback* _callback);

/**
 * @brief Get Global Ps Config Api
 * @return pointer CONFIGINFO_API *
 */
CONFIGINFO_API * getGlobalPsConfigApi(void);

/**
 * @brief Init Mosquitto Client Api
 * @param host_ip
 * @return 0 on success,
 *        -1 on fail
 */
int initMosquittoClientApi(const char *host_ip);

/**
 * @brief Kill Mosquitto Client Api
 * @return 
 * 	MOSQ_ERR_SUCCESS - on success.
 * 	MOSQ_ERR_INVAL   - if the input parameters were invalid.
 * 	MOSQ_ERR_NO_CONN - if the client isn't connected to a broker.
 */
int killMosquittoClientApi();

/**
 * @brief Mosquitto Client Api
 * @param topic - topic of MQTT
 * @param payload - the message of data
 * @return (void)
 */
void mosquittoClientApi(const char *topic, const char *payload);

/**
 * @brief Mqtt Send File By Name
 * @param full_file_name
 * @param num_file
 * @return 0 on success,
 *        -1 on fail 
 */
int mqttSendFileByName(char * full_file_name, int num_file); //num_file - for receiver side


/**
 * @brief Set Peer Ip Local
 * @param ip_local
 * @return (void)
 */
void setPeerIpLocal(const char *ip_local);

/**
 * @brief Get File Form Ps
 * @param index
 * @return (void)
 */
void getFileFormPs(int index);

/**
 * @brief Do Update Params Vs
 * @return (void)
 */
void doUpdateParamsVs();

/**
 * @brief Delete Ram Memory Config
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int deleteRamMemoryConfig();

/**
 * @brief Reset App Foresight
 * @return (void)
 */
void resetAppForesight();

// ##########################
// ###    Get Version     ###
// ##########################

/**
 * @brief Get Ps Version
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int getPsVersion();

/**
 * @brief Get Vs Version
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form VS
 */
int getVsVersion();

/**
 * @brief Get Dsp Version
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form Dsp
 */
int getDspVersion();

/**
 * @brief Get build Version
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int getBuildVersion();

// ###################################
// ###    Control State Meshing    ###
// ###################################


/**
 * @brief Set Status Control State Meshing of Ip
 * @param status
 * @return (void)
 */
void setStatusIp(IpStatus status);

/**
 * @brief Get Status Control State Meshing of Ip
 * @return 
 *      Control State Meshing of Ip Status
 */
IpStatus getStatusIp();

/**
 * @brief Set Status Control State Meshing of Set Algo
 * @param status
 * @return (void)
 */
void setStatusSetAlgo(SetAlgoStatus status);

/**
 * @brief Get Status Control State Meshing of Set Algo
 * @return Control State Meshing of Algo Status
 */
SetAlgoStatus getStatusSetAlgo();

/**
 * @brief Set Status Control State Meshing of Set AutoCalib
 * @param status
 * @return (void)
 */
void setStatusSetAutoCalib(SetAutoCalibStatus status);

/**
 * @brief get Status Control State Meshing of Set AutoCalib
 * @return 
 *      Control State Meshing of AutoCalib Status
 */
SetAutoCalibStatus getStatusSetAutoCalib();


/**
 * @brief Set Status Control State Meshing of Set Gyro Calib
 * @param status
 * @return (void)
 */
void setStatusSetGyroCalib(SetGyroCalibStatus status);

/**
 * @brief Get Status Control State Meshing of Set Gyro Calibration
 * @return 
 *      Control State Meshing of Gyro Calibration Status
 */
SetGyroCalibStatus getStatusSetGyroCalib();

/**
 * @brief Set Status Control State Meshing of Set Live Cameras
 * @param status
 * @return (void)
 */
void setStatusSetLiveCameras(SetLiveCamerasStatus status);

/**
 * @brief Get Status Control State Meshing of Set Live Cameras
 * @return 
 *      Control State Meshing of Live Cameras Status
 */
SetLiveCamerasStatus getStatusSetLiveCameras();

/**
 * @brief Set Status Control State Meshing of Set Record Live Cameras
 * @param status
 * @return (void)
 */
void setStatusSetRecordLiveCameras(SetRecordLiveCamerasStatus status);

/**
 * @brief Get Status Control State Meshing of Set Record Live Cameras
 * @return 
 *      Control State Meshing of Record Live Cameras Status
 */
SetRecordLiveCamerasStatus getStatusSetRecordLiveCameras();

/**
 * @brief Set Status Control State Meshing of Set Cmd Status
 * @param status
 * @return (void)
 */
void setStatusOfSetCmdStatus(SetSendCmdStatus status);

/**
 * @brief Get Status Control State Meshing of Set Cmd Status
 * @return 
 *      Control State Meshing of Send Cmd Status
 */
SetSendCmdStatus getStatusOfSetCmdStatus();

/**
 * @brief Set Status Control State Meshing of Check Dir Config Exist
 * @param status
 * @return (void)
 */
void setStatusCheckDirConfigExist(CheckDirConfigCameraExistStatus status);

/**
 * @brief Get Status Control State Meshing of Check Dir Config Exist
 * @return 
 *      Control State Meshing of Check Diractory Config Camera Exist Status
 */     
CheckDirConfigCameraExistStatus getStatusCheckDirConfigExist();

/**
 * @brief Set Status Control State Meshing of Set Sensor Cmd Status
 * @param status
 * @return (void)
 */
void setStatusOfSetSensorCmdStatus(SetSendSensorCmdStatus status);

/**
 * @brief Get Status Control State Meshing of Set Sensor Cmd Status
 * @return
 *     Control State Meshing of Send Sensor Cmd Status 
 */
SetSendSensorCmdStatus getStatusOfSetSensorCmdStatus();

/**
 * @brief Set Status Playback
 * @param status
 * @return (void)
 */
void setStatusPlayback(PlaybackStatus status);

/**
 * @brief Get Status Control State Meshing of Playback
 * @return 
 *      Control State Meshing of Playback Status
 */
PlaybackStatus getStatusPlayback();

/**
 * @brief Set Status Control State Meshing of Set Disparity
 * @param status
 * @return (void)
 */
void setStatusSetDisparity(SetDisparityType status);

/**
 * @brief Get Status Control State Meshing of Set Disparity
 * @return 
 *      Control State Meshing of Disparity Type
 */
SetDisparityType getStatusSetDisparity();

/**
 * @brief Send Message Validation Status
 * 
 * @param validation_status true or false
 * @param sensor_type vis or ir
 * @return (void)
 */
void sendMessageValidationStatus(const char *validation_status, const char *sensor_type);

/**
 * @brief Copy Targets To Movie
 *      Example:
 *  will do copy from src: ~/.config/Validation/targets_gt_vis.json to dst: /mnt/foresight_videos/FS_20200913_124700/VIS/Validation/.
 * @param sensor_type vis or ir
 * @param movie_folder FS_20200913_124700
 * @return (void)
 */
void copyTargetsToMovie(const char *sensor_type, const char *movie_folder);


/**
 * @brief Set All Windows Sources And Scales
 * @param source_windows1  0 =LeftDay 1=RightDay 2=LeftNight 3=RightNight
 * @param scale_windows1   25 or 50 or 100
 * @param source_windows2  0 =LeftDay 1=RightDay 2=LeftNight 3=RightNight
 * @param scale_windows2   25 or 50 or 100
 * @param source_windows3  0 =LeftDay 1=RightDay 2=LeftNight 3=RightNight
 * @param scale_windows3   25 or 50 or 100
 * @param source_windows4  0 =LeftDay 1=RightDay 2=LeftNight 3=RightNight
 * @param scale_windows4   25 or 50 or 100
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int setAllWindowsSourcesAndScales(int source_windows1, int scale_windows1, int source_windows2, int scale_windows2,
                                  int source_windows3, int scale_windows3, int source_windows4, int scale_windows4 );

// ##########################
// ###      Playback      ###
// ##########################

/**
 * @brief Set Dir For Playback Path
 * @param dir_path
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int setDirForPlaybackPath(char *dir_path);

/**
 * @brief Read Dir For Playback
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int readDirForPlayback();

/**
 * @brief Set Algoritem of Detection
 * @param algo_name  ai_and_stereo or only_ai or only_stereo or no_algo
 * @return 
 *      NO_ERROR        - on success.
 *      ERROR_TIME_OUT  - error timeout message form PS
 */
int setAlgo(const char *algo_name); 

/**
 * @brief load Playback File
 * @param json no_json or json or json_and_metadata or validation 
 * @param dir  dirctory name of movie to play 
 * @param use_vis 0-no use vis ,1- use vis
 * @param use_ir  0-no use ir  ,1- use ir
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form PS
 *      ERROR_INPUT_PARAMS - erroe input paramter json
 */
int loadPlaybackFile(const char *json , const char *dir, int use_vis =1 , int use_ir =1); // json is no_json, json, json_and_metadata

/**
 * @brief Load Playback File Metadata
 * @param metadata_req  see enum MetadataRequest
 * @param dir  dirctory name of movie to play 
 * @param use_vis 0-no use vis ,1- use vis
 * @param use_ir  0-no use ir  ,1- use ir
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form PS
 */
int loadPlaybackFileMetadata(const MetadataRequest metadata_req , const char *dir, int use_vis = 1, int use_ir = 1);

/**
 * @brief Playback Run Video
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int playbackRunVideo();

/**
 * @brief Playback Pause Video
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int playbackPauseVideo();

/**
 * @brief Playback Home Video go to start video
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int playbackHomeVideo();

/**
 * @brief Playback Next Frame Video
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int playbackNextFrameVideo();

/**
 * @brief Playback Loop Video
 * @param flag - loop  or no_loop
 * @return
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - erroe input paramter flag
 */
int playbackLoopVideo(const char *flag); // loop no_loop

/**
 * @brief Playback Go To Frame
 * @param frame_number - farme number to play form
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int playbackGoToFrame(const char *frame_number);


/**
 * @brief Interpreter Show Video - preset of Show Video
 * @param num look enum ShowVideoshowVideo
 * @return 
 *      show_video_val - see enum RequestData
 */
unsigned int interpreterShowVideo(ShowVideoshowVideo num);

/**
 * @brief Show Display
 * @param int day_request_data   - see enum RequestData
 * @param int night_request_data - see enum RequestData
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int showDisplay(unsigned int day_request_data, unsigned int night_request_data);

/**
 * @brief Request Ranger in video
 * @param source LEFT_VIS or LEFT_IR or DISPARITY_VIS or DISPARITY_IR
 * @param pos_x pixel x in video
 * @param pos_y pixel y in video
 * @return (void)
 */
void requestRanger(RangerSourceDisplayData source , int pos_x, int pos_y);

/**
 * @brief Disable Request Ranger
 * @param source LEFT_VIS or LEFT_IR or DISPARITY_VIS or DISPARITY_IR
 * @return (void)
 */
void disableRequestRanger(RangerSourceDisplayData source);

/**
 * @brief Set Disparity Type
 * @param cam - vis or ir or both
 * @param disp_type - BlockMatching or AnyNet or Raft or RaftNP 
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form PS
 *      ERROR_INPUT_PARAMS - error input paramter cam or disp_type
 */
int setDisparityType(const char *cam, const char *disp_type);

/**
 * @brief Set Send Obstacles Mqtt - Enable or diseble to send Obstacles thorw Mqtt protcol
 * @param flag_send_obs_mqtt - true or false
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form PS
 *      ERROR_INPUT_PARAMS - error input paramter cam or disp_type
 */
int setSendObstMqtt(const char *flag_send_obs_mqtt);

/**
 * @brief Send reqest to Get List of playback movies in diractory
 * @param path - path of the playback directory
 * @return (void)
 */
void brwGetList(const char *path);

// ##########################
// ###  Gyro Calibration  ###
// ##########################

/**
 * @brief Start Gyro Calibratore
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form PS 
 */
int startGyroCalib();

// ##########################
// ###  Auto Calibration  ###
// ##########################

/**
 * @brief Auto Calibraton Start Manual
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int autoCalibStartManual(const char *cam);

/**
 * @brief Auto Calibraton Force Stop
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int autoCalibForceStop(const char *cam);

/**
 * @brief Auto Calibration Enable Miss Calibration
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int autoCalibEnableMissCalibration(const char *cam);

/**
 * @brief Auto Calibration Disable Miss Calibration
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
*/
int autoCalibDisableMissCalibration(const char *cam);

/**
 * @brief Auto Calibration Enable Trig
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int autoCalibEnableTrig(const char *cam);

/**
 * @brief Auto Calibration Disable Trig
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam

 */
int autoCalibDisableTrig(const char *cam);

/**
 * @brief Auto Calibration Set Yml Lab
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int autoCalibSetYmlLab(const char *cam);

/**
 * @brief Auto Calibration Set Yml AC2
 * @param cam - vis or ir or both
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int autoCalibSetYmlAc2(const char *cam);

/**
 * @brief Set Paramter in Auto Calibration Ac2 Max Angle
 * @param cam - vis or ir or both
 * @param max_angle -MAxsimum Angle
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int setAutoCalibAc2MaxAngle(const char *cam, float max_angle); 

/**
 * @brief Set Paramter in Auto Calibration Ac2 Minimum Frame
* @param cam - vis or ir or both
 * @param min_frame -Minimum Frame
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int setAutoCalibAc2MinFrame(const char *cam, int min_frame);   // cam is day or night only

/**
 * @brief create Auto Calibration File
 * @param flag_crate_file -true or false
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 *      ERROR_INPUT_PARAMS - error input cam
 */
int createAutoCalibFile(const char *flag_crate_file);

// ##########################
// ###      camera        ###
// ##########################

/**
 * @brief Send Reqest to PS Get Sensors Parameters
 * @return 
 *      NO_ERROR           - on success.
 *      ERROR_TIME_OUT     - error timeout message form VS
 */
int getSensorsParameters();

/**
 * @brief send file FILE_CAMEMRA_CONFIG_OUT of Sensors Parameters to PS
 * @return (void)
 */
void setSensorsParameters();

/**
 * @brief prepare Camera Parameters To Send to PS
 * @param num_day_cameras 1-rig , 2- modular , 3 -stereo to mono
 * @param gyro_type -  no_gyro or gyro_gps or obd
 * @param flag_get_sensor_parameters true - send reqest to get sensor paramsters
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 *      ERROR_FAIL_TO_OPEN_FILE      
 */
int prepareCameraParametersToSend(int num_day_cameras, const char *gyro_type, int flag_get_sensor_parameters =true);

/**
 * @brief Reqest Set Gyro Type to PS 
 * @param gyro_type - no_gyro or gyro_gps or obd
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int setGyroType(const char *gyro_type );  


/**
 * @brief Reqest Set Cameras Parameters to PS
 * @param vis_num_cameras 1-rig , 2- modular , 3 -stereo to mono
 * @param use_90_deg   - 0- use 32 deg , 1- use 90 deg
 * @param ir_per_Pixel - 8- 8 bit per pixel, 16- 16 bit per pixel
 * @param use_lattice  - 0- no used lattice serial, 1 -used lattice serial
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 *      ERROR_INPUT_PARAMS      - error input vis_num_cameras or ir_per_Pixel
 */
int setCamerasParameters(int vis_num_cameras, int use_90_deg, int ir_per_Pixel, int use_lattice);


/**
 * @brief Reqest Set Camera Write File Format to PS
 * @param file_vis_format - “avi” or ”yuv” or “rgb”
 * @param file_ir_format  - 0- 8bpp, 1 - 16bpp
 * @param no_send_video   - 0- send video, 1-not send video
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 *      ERROR_INPUT_PARAMS      - error input file_vis_format 
 */
int setCameraWriteFileFormat(const char *file_vis_format, int file_ir_format, int no_send_video); 


/**
 * @brief Reqest set Used Camera And Record to PS
 * @param used_vis_camera      - Enable to use vis camera  
 * @param used_ir_camera       - Enable to use ir camera
 * @param enable_record_files  - Enable to recoed files
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS 
 */
int setUsedCameraAndRecord(int used_vis_camera, int used_ir_camera, int enable_record_files);

/**
 * @brief Reqest Set Camera to be Left or Right to PS
 * @param sensor_type          - vis or ir
 * @param sensor_1_left_right  - "stereo_vis" or "left" or "right" or "none"
 * @param sensor_2_left_right  - "stereo_vis" or "left" or "right" or "none"
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 *      ERROR_INPUT_PARAMS      - error input  sensor_type or sensor_1_left_right or sensor_2_left_right
 */
int setCameraLeftRight(const char*sensor_type, const char * sensor_1_left_right,
                       const char * sensor_2_left_right); 
                                                                
/**
 * @brief Copy Current Config Camera Files form dir ~/.config/foresight to  ~/.config/foresight/save_config
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int copyCurrentConfigCameraFiles();

/**
 * @brief Restore Config Camera Files form dir ~/.config/foresight/save_config to ~/.config/foresight
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int restoreConfigCameraFiles();

/**
 * @brief Reqest to Check If Dir Save Config Exist to PS - if directory ~/.config/foresight/save_config exsit
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int checkIfDirSaveConfigExist();

/**
 * @brief Reqsest Start Live Camera to PS - load Vision Service as connnect camera.
 * @param flag_shm - 0 - no  use sheard memory protcol , 1 - use sheard memory protcol
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
*/
int startLiveCamera(int flag_shm = false);

/**
 * @brief Reqsest Stop Live Camera to PS - kill vision service
* @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int stopLiveCamera();

/**
 * @brief Reqsest Set Crop Params
 * @param sensor_type    - vis or ir
 * @param flag_crop      - 0- not do crop, 1- do crop
 * @param crop_center    - crop center y pixel in video
 * @param crop_size      - crop size in pixels form crop center in video
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 *      ERROR_INPUT_PARAMS      - error input  sensor_type 
 */
int setCropParams(const char*sensor_type, bool flag_crop, int crop_center, int crop_size);

// ################################
// ###      Record camera       ###
// ################################

/**
 * @brief Requset Get Configuration File
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int getConfigurationFile(); // IP and record dir

/**
 * @brief Set Dir For Record Path
 * @param dir -dirctory of recoed path
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int setDirForRecordPath(char *dir);

/**
 * @brief Save Cfg Info -send file FILE_CONFIG_OUT to PS
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 *      ERROR_FAIL_TO_OPEN_FILE 
 */
int saveCfgInfo();

/**
 * @brief Request to Start Record Camera to VS 
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form VS
 */
int startRecordCamera();

/**
 * @brief Request to Stop Record Camera to VS
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form VS
 */
int stopRecordCamera();

// ################################
// ###   Kill vision service    ###
// ################################

/**
 * @brief Requset to Kill VisionService to PS
 * @return 
 *      NO_ERROR                - on success.
 *      ERROR_TIME_OUT          - error timeout message form PS
 */
int killVisionService();

#endif //MOSQUITTO_CLIENT_API_MOSQUITTO_CLIENT_API_H
